<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Servers\SuspensionService;

class SuspensionController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    protected $alert;

    /**
     * @var SuspensionService
     */
    protected $suspensionService;

    /**
     * SuspensionController constructor.
     * @param AlertsMessageBag $alert
     * @param SuspensionService $suspensionService
     */
    public function __construct(AlertsMessageBag $alert, SuspensionService $suspensionService)
    {
        $this->alert = $alert;
        $this->suspensionService = $suspensionService;
    }

    /**
     * @param Request $request
     * @param User $user
     * @return \Illuminate\Http\RedirectResponse
     * @throws DisplayException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function toggleSuspension(Request $request, User $user)
    {
        $this->validate($request, [
            'is_suspended' => 'required|int|min:0|max:1',
            'suspend_cause' => 'max:191',
        ]);

        if ($user->id == Auth::user()->id) {
            throw new DisplayException('You can\'t modify your suspension status.');
        }

        $servers = DB::table('servers')->where('owner_id', '=', $user->id)->get();
        foreach ($servers as $server) {
            try {
                $this->suspensionService->toggle(Server::find($server->id), ((int) $request->input('is_suspended', 0) == 0 ? SuspensionService::ACTION_UNSUSPEND : SuspensionService::ACTION_SUSPEND));
            } catch (\Throwable $e) {
                throw new DisplayException('Failed to suspend / unsuspend a server. Please try again...');
            }
        }

        DB::table('users')->where('id', '=', $user->id)->update([
            'is_suspended' => (int) $request->input('is_suspended', 0),
            'suspend_cause' => ((int) $request->input('is_suspended', 0) == 0 ? null : trim($request->input('suspend_cause', ''))),
        ]);

        $this->alert->success('You\'ve successfully update suspension status.')->flash();

        return back();
    }
}